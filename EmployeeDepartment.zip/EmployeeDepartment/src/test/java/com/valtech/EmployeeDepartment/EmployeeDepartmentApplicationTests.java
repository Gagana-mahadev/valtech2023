package com.valtech.EmployeeDepartment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeDepartmentApplicationTests {

	@Test
	void contextLoads() {
	}

}
